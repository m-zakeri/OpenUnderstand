package org.craftedsw.harddependencies.trip;

public class Trip {

}
