package org.craftedsw.harddependencies.exception;

public class UserNotLoggedInException extends Exception {

	private static final long serialVersionUID = 8959479918185637340L;

}
