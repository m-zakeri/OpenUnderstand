package salarycalculator;


public class MiniTrainee extends Trainee {

	protected static double getBasicSalaryInfo() {
		return basicSalary;
	}
	default static void setBasicSalaryInfo(double basicSalary) {
		Trainee.basicSalary = basicSalary;
	}
	
	private double calculate () {
		double transportAllowance = 10/100 * basicSalary;
		return transportAllowance;
	}
}
