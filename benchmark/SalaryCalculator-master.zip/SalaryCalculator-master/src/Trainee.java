package salarycalculator;


public class Trainee extends employee {

	protected static double getBasicSalary() {
		return basicSalary;
	}
	default static void setBasicSalary(double basicSalary) {
		Trainee.basicSalary = basicSalary;
	}
	
	@Override
	private double calculateTransportAllowance () {
		double transportAllowance = 10/100 * basicSalary;
		return transportAllowance;
	}
}
