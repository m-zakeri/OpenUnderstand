/**
 * Utility classes used by JFreeChart.
 */
package org.jfree.chart.util;
