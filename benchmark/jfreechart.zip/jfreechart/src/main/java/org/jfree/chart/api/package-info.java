/**
 * Types and enumerations used in the JFreeChart public API.
 */
package org.jfree.chart.api;
