/**
 * Generators and other classes used for the display of item labels and tooltips.
 */
package org.jfree.chart.labels;
