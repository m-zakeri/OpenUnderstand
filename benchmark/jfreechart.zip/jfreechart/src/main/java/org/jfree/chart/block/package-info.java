/*
 * Blocks and layout classes used extensively by the {@link org.jfree.chart.title.LegendTitle} class.
 */
package org.jfree.chart.block;
