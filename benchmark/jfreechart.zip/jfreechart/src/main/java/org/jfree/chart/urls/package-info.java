/**
 * Classes for adding URLS to charts for HTML image map generation. 
 */
package org.jfree.chart.urls;
