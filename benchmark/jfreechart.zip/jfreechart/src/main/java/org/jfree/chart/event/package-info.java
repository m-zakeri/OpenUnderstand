/**
 * Event classes and listener interfaces, used to provide a change
 * notification mechanism so that charts are automatically redrawn
 * whenever changes are made to any chart component.
 */
package org.jfree.chart.event;
