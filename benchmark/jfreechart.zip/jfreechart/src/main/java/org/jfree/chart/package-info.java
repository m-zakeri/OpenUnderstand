/**
 * Core classes for JFreeChart including {@link org.jfree.chart.JFreeChart} and {@link org.jfree.chart.ChartFactory}. 
 */
package org.jfree.chart;
