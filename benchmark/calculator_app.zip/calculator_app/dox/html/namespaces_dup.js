var namespaces_dup =
[
    [ "com", null, [
      [ "calculator", null, [
        [ "app", null, [
          [ "display", "namespacecom_1_1calculator_1_1app_1_1display.html", "namespacecom_1_1calculator_1_1app_1_1display" ],
          [ "init", "namespacecom_1_1calculator_1_1app_1_1init.html", "namespacecom_1_1calculator_1_1app_1_1init" ],
          [ "method", "namespacecom_1_1calculator_1_1app_1_1method.html", "namespacecom_1_1calculator_1_1app_1_1method" ]
        ] ]
      ] ]
    ] ]
];