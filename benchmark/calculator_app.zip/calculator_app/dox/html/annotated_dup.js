var annotated_dup =
[
    [ "com", null, [
      [ "calculator", null, [
        [ "app", null, [
          [ "display", "namespacecom_1_1calculator_1_1app_1_1display.html", [
            [ "print_fail", "classcom_1_1calculator_1_1app_1_1display_1_1print__fail.html", "classcom_1_1calculator_1_1app_1_1display_1_1print__fail" ],
            [ "print_success", "classcom_1_1calculator_1_1app_1_1display_1_1print__success.html", "classcom_1_1calculator_1_1app_1_1display_1_1print__success" ],
            [ "println", "classcom_1_1calculator_1_1app_1_1display_1_1println.html", "classcom_1_1calculator_1_1app_1_1display_1_1println" ]
          ] ],
          [ "init", "namespacecom_1_1calculator_1_1app_1_1init.html", [
            [ "Main", "classcom_1_1calculator_1_1app_1_1init_1_1Main.html", "classcom_1_1calculator_1_1app_1_1init_1_1Main" ]
          ] ],
          [ "method", "namespacecom_1_1calculator_1_1app_1_1method.html", [
            [ "basic_operation", "classcom_1_1calculator_1_1app_1_1method_1_1basic__operation.html", "classcom_1_1calculator_1_1app_1_1method_1_1basic__operation" ],
            [ "fibonacci", "classcom_1_1calculator_1_1app_1_1method_1_1fibonacci.html", "classcom_1_1calculator_1_1app_1_1method_1_1fibonacci" ],
            [ "integral", "classcom_1_1calculator_1_1app_1_1method_1_1integral.html", "classcom_1_1calculator_1_1app_1_1method_1_1integral" ],
            [ "printLog", "classcom_1_1calculator_1_1app_1_1method_1_1printLog.html", "classcom_1_1calculator_1_1app_1_1method_1_1printLog" ]
          ] ]
        ] ]
      ] ]
    ] ]
];