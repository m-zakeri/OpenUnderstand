var searchData=
[
  ['sum_32',['sum',['../classcom_1_1calculator_1_1app_1_1method_1_1basic__operation.html#afc222c1f39047907cdecc078942d7daa',1,'com.calculator.app.method.basic_operation.sum(int a, int b)'],['../classcom_1_1calculator_1_1app_1_1method_1_1basic__operation.html#afea225f4238b0613ac56cbad6c842c92',1,'com.calculator.app.method.basic_operation.sum(double a, double b)']]]
];
