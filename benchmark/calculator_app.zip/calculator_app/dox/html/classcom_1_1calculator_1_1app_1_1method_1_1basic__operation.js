var classcom_1_1calculator_1_1app_1_1method_1_1basic__operation =
[
    [ "multiplication", "classcom_1_1calculator_1_1app_1_1method_1_1basic__operation.html#a395856a9d93b0d0b22383fb69389dc70", null ],
    [ "multiplication", "classcom_1_1calculator_1_1app_1_1method_1_1basic__operation.html#af3ce776ee385bd7d9e3d535da648bfc1", null ],
    [ "pow", "classcom_1_1calculator_1_1app_1_1method_1_1basic__operation.html#acdf692ee53e9b281be9dee0648f2c23f", null ],
    [ "sum", "classcom_1_1calculator_1_1app_1_1method_1_1basic__operation.html#afea225f4238b0613ac56cbad6c842c92", null ],
    [ "sum", "classcom_1_1calculator_1_1app_1_1method_1_1basic__operation.html#afc222c1f39047907cdecc078942d7daa", null ]
];