package com.calculator.app.method;

import com.calculator.app.init.Main;

public class basic_operation {
    public static int sum(int a,int b)
    {
        return a+b;
    }
    public static double sum(double a, double b)
    {
        return a+b;
    }
    public static int multiplication(int a, int b)
    {
        return a*b;
    }
    public static double multiplication(double a, double b)
    {
        return a*b;
    }
    public static double pow(double a, double power)
    {
        return Math.pow(a,power);
    }
}