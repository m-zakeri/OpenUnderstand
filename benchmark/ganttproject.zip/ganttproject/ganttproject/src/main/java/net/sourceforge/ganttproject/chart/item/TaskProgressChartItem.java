/*
 * Created on 21.11.2004
 */
package net.sourceforge.ganttproject.chart.item;

import net.sourceforge.ganttproject.task.Task;

/**
 * @author bard
 */
public class TaskProgressChartItem extends ChartItem {
  public TaskProgressChartItem(Task task) {
    super(task);
  }
}
