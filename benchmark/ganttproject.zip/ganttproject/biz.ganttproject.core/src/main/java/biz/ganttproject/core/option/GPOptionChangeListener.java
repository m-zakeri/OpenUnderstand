/*
 * Created on 05.04.2005
 */
package biz.ganttproject.core.option;

/**
 * @author bard
 */
public interface GPOptionChangeListener {
  public void optionsChanged();
}
