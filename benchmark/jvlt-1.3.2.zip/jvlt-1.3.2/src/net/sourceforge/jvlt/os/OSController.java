package net.sourceforge.jvlt.os;

import net.sourceforge.jvlt.ui.JVLTUI;

public interface OSController {
	void setMainView(JVLTUI ui);
}
