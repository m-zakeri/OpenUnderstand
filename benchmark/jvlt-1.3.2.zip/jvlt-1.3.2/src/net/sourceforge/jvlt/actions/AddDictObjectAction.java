package net.sourceforge.jvlt.actions;

import net.sourceforge.jvlt.core.Reinitializable;

public class AddDictObjectAction extends DictObjectAction {
	public AddDictObjectAction(Reinitializable obj) {
		super(obj);
	}
}
