package net.sourceforge.jvlt.actions;

public abstract class QueryAction extends UndoableAction {
}
