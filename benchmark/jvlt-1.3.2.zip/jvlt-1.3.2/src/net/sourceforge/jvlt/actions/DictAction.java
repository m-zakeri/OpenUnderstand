package net.sourceforge.jvlt.actions;

public abstract class DictAction extends UndoableAction {
}
