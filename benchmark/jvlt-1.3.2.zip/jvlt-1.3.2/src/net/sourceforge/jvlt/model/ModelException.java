package net.sourceforge.jvlt.model;

public class ModelException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	ModelException(String message) {
		super(message);
	}
}
