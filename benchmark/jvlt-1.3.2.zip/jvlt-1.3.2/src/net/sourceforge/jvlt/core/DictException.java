package net.sourceforge.jvlt.core;

public class DictException extends Exception {
	private static final long serialVersionUID = 1L;

	public DictException(String message) {
		super(message);
	}
}
