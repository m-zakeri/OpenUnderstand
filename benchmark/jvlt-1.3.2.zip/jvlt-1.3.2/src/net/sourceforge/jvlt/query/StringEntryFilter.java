package net.sourceforge.jvlt.query;

public interface StringEntryFilter {
	String getFilterString();

	void setFilterString(String str);
}
